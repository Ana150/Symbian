package database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class SQLHelper extends SQLiteOpenHelper {

    /** ATRIBUTOS DA CLASSE CONNECTION**/

    private static final String DB_NAME = "Symbian";
    private static final int DB_VESION = 1;
    private static SQLHelper INSTANCE;

    /* Método de verificar se a conexao está aberta. */

    public static SQLHelper getInstance(Context context) {
        if (INSTANCE == null){
            INSTANCE = new SQLHelper(context);
        }

        return INSTANCE;

    }

    /* Método construtor: recebe os valores iniciais de abertura da conexão. */
    public SQLHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VESION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE tbl_usuario" +
                "(cod_usuario INTEGER PRIMARY KEY," +
                "nome TEXT," +
                "sobrenome TEXT," +
                "login TEXT," +
                "senha TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("CREATE TABLE tbl_endereco" +
                "(cod_endereco INTEGER PRIMARY KEY," +
                "cod_usuario INTEGER," +
                "cep TEXT," +
                "numero TEXT," +
                "complemento TEXT," +
                "FOREIGN KEY (cod_usuario) REFERENCES tbl_usuario(cod_usuario))");

    }

    public int addUser(String nome, String sobrenome, String login, String senha){

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        try {

            sqLiteDatabase.beginTransaction();
            ContentValues values = new ContentValues();

            values.put("nome", nome);
            values.put("sobrenome", sobrenome);
            values.put("login", login);
            values.put("senha", senha);

            int cod_usuario = (int) sqLiteDatabase.insertOrThrow("tbl_usuario", null, values);
            sqLiteDatabase.setTransactionSuccessful();

            return cod_usuario;

        }catch (Exception e){
            Log.d("SQLITE-", e.getMessage());
            return 0;
        }
        finally {
            if (sqLiteDatabase.isOpen()){
                sqLiteDatabase.endTransaction();
            }
        }
    }

    public boolean addEndereco(String cep, String numero, String complemento){

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        int cod_endereco = 0;

        try {

            sqLiteDatabase.beginTransaction();
            ContentValues values = new ContentValues();

            values.put("cep", cep);
            values.put("numero", numero);
            values.put("complemento", complemento);

            sqLiteDatabase.insertOrThrow("tbl_endereco", null, values);
            sqLiteDatabase.setTransactionSuccessful();

            return true;

        }catch (Exception e){
            Log.d("SQLITE-", e.getMessage());
            return true;
        }
        finally {
            if (sqLiteDatabase.isOpen()){
                sqLiteDatabase.endTransaction();
            }
        }
    }

    public int login(String login, String senha){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM tbl_usuario WHERE login = ? AND senha = ?",
                new String[]{login, senha});

        int cod_usuario = 0;

        try {

            if (cursor.moveToFirst()){
                cod_usuario = cursor.getInt(cursor.getColumnIndex("cod_usuario"));

                return cod_usuario;

            }

            return 0;

        }catch (Exception e){

            Log.d("SQLITE-", e.getMessage());

        }finally{

            if (cursor != null && !cursor.isClosed()){

                cursor.close();

            }else{

            }
        }
        return 0;
    }
}

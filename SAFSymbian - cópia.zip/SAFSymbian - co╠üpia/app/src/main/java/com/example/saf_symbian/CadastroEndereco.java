package com.example.saf_symbian;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import database.SQLHelper;

public class CadastroEndereco extends AppCompatActivity {
    private EditText txtCep;
    private EditText txtNumero;
    private EditText txtComplemento;
    private Button btnCadastrarEndereco;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_endereco);

        //captura dos componentes graficos da activity
        txtCep = findViewById(R.id.txtCep);
        txtNumero = findViewById(R.id.txtNumero);
        txtComplemento = findViewById(R.id.txtComplemento);
        btnCadastrarEndereco = findViewById(R.id.btnCadastrarEndereco);

        btnCadastrarEndereco.setOnClickListener(view -> {
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.titulo_cadastro_endereco))
                    .setMessage(getString(R.string.mensagem_cadastro_endereco))
                    .setPositiveButton(R.string.salvar, (dialog1, which)->{
                        //acao do botao
                        String cep = txtCep.getText().toString();
                        String numero = txtNumero.getText().toString();
                        String complemento = txtComplemento.getText().toString();

                        boolean cadastroEndereco = SQLHelper.getInstance(CadastroEndereco.this)
                                .addEndereco(cep, numero, complemento);

                    })
                    .setNegativeButton(R.string.cancelar, (dialog1, which)->{}).create();

            dialog.show();

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Log.d("MENUITEM-", String.valueOf(item.getItemId()));

        switch (item.getItemId()){

            case R.id.menuCadastrarEndereco:
                startActivity(new Intent(this, CadastroEndereco.class));
                break;

            case R.id.menuSair:
                startActivity(new Intent(this, MainActivity.class));
                break;

        }

        return super.onOptionsItemSelected(item);
    }
}